package com.example.iot_ha.ui.viewmodels

import androidx.lifecycle.ViewModel
import com.example.iot_ha.data.local.RoomLocalDatabase


class HomeViewModel(db: RoomLocalDatabase) : ViewModel()