package com.example.iot_ha.ui.screens.home

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun ScheduleScreen() {
    Text("Schedule Screen")
}